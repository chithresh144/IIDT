import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
  const location = useLocation();
  const showTasksLink = location.pathname !== '#';

  return (
    <nav className="navbar">
      <div className="navbar-center">
        {showTasksLink && (
          <Link to="/tasks" className="nav-link">
            Tasks
          </Link>
        )}
      </div>
      <div className="navbar-right">
        <Link to="/login" className="nav-link">
          Login
        </Link>
        <Link to="/register" className="nav-link">
          Register
        </Link>
      </div>
    </nav>
  );
};

export default NavBar;
