import React from 'react';
import { Link } from 'react-router-dom';
import './Login.css';

const Login = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Login submitted');
  };

  return (
    <div className="login-container">
      <div className= "login-content"> 
        <h2>Login</h2>
        <form onSubmit={handleSubmit} className="login-form">
          <label className="login-label">
            Username:
            <input type="text" className="login-input" />
          </label>
          <label className="login-label">
            Password:
            <input type="password" className="login-input" />
          </label>
          <button type="submit" className="login-button">Login</button>
        </form>
        <p>
          Don't have an account? <Link to="/register" className="login-link">Register here</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;