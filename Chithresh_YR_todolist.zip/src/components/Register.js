import React from 'react';
import { Link } from 'react-router-dom';
import './Register.css';

const Register = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Registration submitted');
  };

  return (
    <div className="register-container">
      <div className="register-content">
        <h2>Register</h2>
        <form onSubmit={handleSubmit} className="register-form">
          <div className="register-field">
            <label htmlFor="username">Username:</label>
            <input type="text" id="username" className="register-input" />
          </div>
          <div className="register-field">
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" className="register-input" />
          </div>
          <button type="submit" className="register-button">Register</button>
        </form>
        <p>
          Already have an account? <Link to="/login" className="register-link">Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
