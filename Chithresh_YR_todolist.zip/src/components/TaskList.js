import React, { useState } from 'react';
import './TaskList.css';

const TaskList = ({ tasks, onDelete, onMarkAsDone, onAddTask }) => {
  const [taskName, setTaskName] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [priority, setPriority] = useState('High');

  const handleAddTask = () => {
    const newTask = {
      id: tasks.length + 1,
      title: taskName,
      description: taskDescription,
      priority: priority
    };
    onAddTask(newTask);
    setTaskName('');
    setTaskDescription('');
    setPriority('High');
  };

  const handleFilterByPriority = (priority) => {
    console.log('Filter by Priority:', priority);
  };

  const handleSortByPriority = (order) => {
    console.log('Sort by Priority:', order);
  };

  return (
    <div className="task-list-container">
      <div className="add-task-container">
        <h2>Add Task</h2>
        <div className="input-container">
          <input
            type="text"
            placeholder="Task Name"
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
          />
          <div className='input-textfield-a'>
          <textarea className='input-textfield'
            placeholder="Task Description"
            value={taskDescription}
            onChange={(e) => setTaskDescription(e.target.value)}
          /></div>
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <button onClick={handleAddTask}>Add Task</button>
        </div>
        <div className="dropdown-container">
          <div className="dropdown">
            <button className="dropbtn">Filter</button>
            <div className="dropdown-content">
              <button onClick={() => handleFilterByPriority('Low')}>Low</button>
              <button onClick={() => handleFilterByPriority('Medium')}>Medium</button>
              <button onClick={() => handleFilterByPriority('High')}>High</button>
            </div>
          </div>
          <div className="dropdown">
            <button className="dropbtn">Sort</button>
            <div className="dropdown-content">
              <button onClick={() => handleSortByPriority('LowToHigh')}>Low to High</button>
              <button onClick={() => handleSortByPriority('HighToLow')}>High to Low</button>
            </div>
          </div>
        </div>
      </div>

      <h2>Task List</h2>
      <div className="task-container">
        {tasks.map((task) => (
          <div className="task" key={task.id}>
            <div className="task-header">
              <span>{task.title}</span>
              <div className="action-buttons">
                <button onClick={() => onMarkAsDone(task.id)}>Mark as Done</button>
                <button onClick={() => onDelete(task.id)}>Delete (Its under developing)</button>
              </div>
            </div>
            <div className="task-details">
              <p>{task.description}</p>
              <span>Priority: {task.priority}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskList;
