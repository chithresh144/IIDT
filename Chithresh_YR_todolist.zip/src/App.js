import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import NavBar from './components/NavBar';
import Login from './components/Login';
import Register from './components/Register';
import TaskList from './components/TaskList';
import './App.css';

const App = () => {
  const [tasks, setTasks] = useState([
    { id: 1, title: 'Task 1', description: 'Description of Task 1', completed: false },
    { id: 2, title: 'Task 2', description: 'Description of Task 2', completed: true },
    { id: 3, title: 'Task 3', description: 'Description of Task 3', completed: false },
  ]);

  const handleAddTask = (newTask) => {
    setTasks([...tasks, newTask]);
  };

  const handleDeleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };

  const handleMarkAsDone = (taskId) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, completed: true } : task)));
  };

  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>ToDo List App</h1>
        </header>
        <NavBar />
        <Switch>
          <Route exact path="/">
            <Login />
          </Route>
          <Route exact path="/login">
            <Login />
          </Route>
          <Route path="/register">
            <Register />
          </Route>
          <Route path="/tasks">
            <TaskList
              tasks={tasks}
              onAddTask={handleAddTask}
              onDeleteTask={handleDeleteTask}
              onMarkAsDone={handleMarkAsDone}
            />
          </Route>
          
        </Switch>
      </div>
    </Router>
  );
};

export default App;