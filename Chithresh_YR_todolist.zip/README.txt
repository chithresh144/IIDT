ToDoList Application

-> Overview

This project is a simple ToDoList application built using MERN stack. It allows users to manage their tasks by adding, deleting, marking as done, and filtering tasks by priority.

-> Components:

- TaskList: Displays a list of tasks with options to mark as done, delete, and filter by priority.
- AddTaskForm: Provides a form to add new tasks with fields for task name, description, and priority.
- NavBar: Navigation bar component for easy navigation between pages.
- Login: Login page for users to authenticate.
- Register: Register page for new users to create an account.

How to Use
1. Create react application with npx create-react-app todolist
2. Navigate to the project directory: `cd todolist`
3. Install dependencies: `npm install`
4. Run the application: `npm start`
5. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

Project Structure

    - src/
    - components/: Contains all React components.
    - NavBar.js: Navigation bar component.
    - NavBar.css: Navigation bar styles
    - Login.js: Login page component.
    - Login.css: Login page styles
    - Register.js: Register page component.
    - Register.css: Register page styles
    - TaskList.js: Task list component.
    - TaskList.css: Task list styles
    - AddTaskForm.js: Form component to add new tasks.
    - App.css: Global styles for the application.
    - App.js: Main component that renders other components based on routes.
    - index.js: Entry point of the application.
    - package-lock.json, package.json: packages and dependencies installed and used for current project 
